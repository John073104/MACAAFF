<?php
session_start();
if (!isset($_SESSION["user"])) {
   header("Location: login.php");
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "test";

$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Add Member
if(isset($_POST['add_member'])) {
    $fullname = $_POST['fullname'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];
    $purok = $_POST['purok'];
    $address = $_POST['address'];
    $timein = $_POST['timein'];
    $timeout = $_POST['timeout'];
    $date = $_POST['date']; // Added date field
    $service = $_POST['service'];

    $sql = "INSERT INTO members (fullname, gender, age, purok, address, timein, timeout, date, service) 
            VALUES ('$fullname', '$gender', '$age', '$purok', '$address', '$timein', '$timeout', '$date', '$service')";
    if (mysqli_query($conn, $sql)) {
        echo "Member added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}

// Read or Display Members
$sql = "SELECT * FROM members";
$result = mysqli_query($conn, $sql);

// Update Member
if(isset($_POST['update_member'])) {
    $id = $_POST['id'];
    $fullname = $_POST['fullname'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];
    $purok = $_POST['purok'];
    $address = $_POST['address'];
    $timein = $_POST['timein'];
    $timeout = $_POST['timeout'];
    $date = $_POST['date']; // Added date field
    $service = $_POST['service'];

    $sql = "UPDATE members SET fullname='$fullname', gender='$gender', age='$age', purok='$purok', 
            address='$address', timein='$timein', timeout='$timeout', date='$date', service='$service' WHERE id='$id'";

    if (mysqli_query($conn, $sql)) {
        echo "Member updated successfully";
    } else {
        echo "Error updating member: " . mysqli_error($conn);
    }
}

// Delete Member
if(isset($_GET['delete_member'])) {
    $id = $_GET['delete_member'];
    $sql = "DELETE FROM members WHERE id='$id'";
    if (mysqli_query($conn, $sql)) {
        echo "Member deleted successfully";
    } else {
        echo "Error deleting member: " . mysqli_error($conn);
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="../css/styl.css">
    <link rel="stylesheet" href="../css/s.css">
   
</head>
<body>
    <?php include './components/header.php'; ?>
    <?php require_once "./components/navbar.php"?>
    
    <h2>Add Member</h2>
    <div class="container">
        <!-- Add Member Form -->
       
        <form method="POST" action="">
            <input type="text" name="fullname" placeholder="Full Name" required><br>
            <input type="text" name="gender" placeholder="Gender" required><br>
            <input type="number" name="age" placeholder="Age" required><br>
            <input type="text" name="purok" placeholder="Purok" required><br>
            <input type="text" name="address" placeholder="Address" required><br>
            <label for="timein">Time In:</label><br>
            <input type="time" name="timein" id="timein" required><br>
            <label for="timeout">Time Out:</label>
            <input type="time" name="timeout" id="timeout" required><br>
            <label for="date">Date:</label><br>
            <input type="date" name="date" id="date" required><br> <!-- Added date field -->
            <input type="text" name="service" placeholder="Service" required><br>
            <button type="submit" name="add_member" class="btn btn-primary">Add Member</button><br>
        </form>
         <!-- Button to Print Members List -->
        <button class="print-button" onclick="window.print()">Print Members List</button>
        <!-- Display Members -->
        <h2>Members List</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Gender</th>
                    <th>Age</th>
                    <th>Purok</th>
                    <th>Address</th>
                    <th>Time In</th>
                    <th>Time Out</th>
                    <th>Date</th> <!-- Added date column -->
                    <th>Service</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>".$row['id']."</td>";
                    echo "<td>".$row['fullname']."</td>";
                    echo "<td>".$row['gender']."</td>";
                    echo "<td>".$row['age']."</td>";
                    echo "<td>".$row['purok']."</td>";
                    echo "<td>".$row['address']."</td>";
                    echo "<td>".$row['timein']."</td>";
                    echo "<td>".$row['timeout']."</td>";
                    echo "<td>".$row['date']."</td>"; // Added date column
                    echo "<td>".$row['service']."</td>";
                    echo "<td>
                            <a href='edit_member.php?id=".$row['id']."' class='edit-btn'>Edit</a> 
                            <a href='?delete_member=".$row['id']."' class='delete-btn' onclick='return confirm(\"Are you sure you want to delete this member?\")'>Delete</a>
                          </td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <?php include './components/footer.php'; ?>
</body>
</html>
