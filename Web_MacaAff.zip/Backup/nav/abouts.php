
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>abouts</title>
  <link rel="stylesheet" href="../css/styles.css">
  <link rel="stylesheet" href="../css/ss.css">
</head>
<body>
  
  <?php include '../components/header.php'; ?>

	<?php require_once "../components/navbar.php"?>

  <br><br><br><br><br>
  <div class="container">
  <div class="item_wrap"><h2>MacaAFF Tool: An Online Platform for Analyzing the Effectiveness and Productivity of Daily Documentation at Barangay Macatoc Health Center</h2></div>
    <div class="item"> 
 </div>
 <div class="item">
            <img src="../img/2.png" alt="About Image">
        </div>
                                                                   
<div class="container">
  <div class="item_wrap">
    <div class="item"> 1. The MacaAFF Tool revolutionizes daily documentation practices at Barangay Macatoc Health Center by providing an intuitive online platform for analyzing effectiveness and productivity.</div>
</div>
   
  </div>
  <div class="item_wrap">
    <div class="item">2. By leveraging data analytics, the MacaAFF Tool offers healthcare professionals at Barangay Macatoc Health Center valuable insights into the efficiency of their daily documentation processes.</div>
    <div class="item">3. With its focus on streamlining operations, the MacaAFF Tool serves as a crucial resource for optimizing the documentation workflow at Barangay Macatoc Health Center.</div>
  </div>
  <div class="item_wrap">
    <div class="item">4. The MacaAFF Tool empowers staff at Barangay Macatoc Health Center to make informed decisions and drive improvements in daily documentation practices through real-time analysis.
</div>
   
  </div>
  <div class="item_wrap">
    <div class="item">5. Through its comprehensive analysis features, the MacaAFF Tool enables stakeholders at Barangay Macatoc Health Center to enhance their documentation practices and ultimately improve patient care outcomes.
</div>
    <div class="item">6. As an online platform tailored for Barangay Macatoc Health Center, the MacaAFF Tool is a valuable tool for tracking and improving the effectiveness and productivity of daily documentation processes.</div>
  </div>
</div>
</div>
</div>
<footer class="footer">
    <div class="container">
        <p>&copy; <?php echo date("2024"); ?> MacaAFF. All rights reserved.</p>
    </div>
</footer>


	<?php include '../components/footer.php'; ?>


 








  





</body>
</html>


