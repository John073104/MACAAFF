
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>HealthI</title>
  <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
  
  <?php include '../components/header.php'; ?>

	<?php require_once "../components/navbar.php"?>

  <div class="container">
	<h1>Health Issues</h1>
	</div>
<div class="container">
	
<ol>
<li>1. Cardiovascular Diseases: Including heart disease, stroke, and high blood pressure.</li>
<li>2. Respiratory Diseases: Such as asthma, chronic obstructive pulmonary disease (COPD), and pneumonia.</li>
<li>3. Cancer: Various types including lung, breast, prostate, and colorectal cancer.</li>
<li>4. Diabetes: Both type 1 and type 2 diabetes, characterized by high blood sugar levels.</li>
<li>5. Obesity: Excessive body weight leading to various health complications.</li>
<li>6. Mental Health Disorders: Including depression, anxiety disorders, bipolar disorder, and schizophrenia.</li>
<li>7. Neurological Disorders: Such as Alzheimer's disease, Parkinson's disease, epilepsy, and multiple sclerosis.</li>
<li>8. Digestive Disorders: Such as irritable bowel syndrome (IBS), Crohn's disease, and ulcerative colitis.</li>
<li>9. Hearing Loss: Including age-related hearing loss, noise-induced hearing loss, and ear infections.</li>
<li>10. Musculoskeletal Disorders: Including arthritis, osteoporosis, and back pain.</li>
<li>11. Infectious Diseases: Including HIV/AIDS, influenza, tuberculosis, and hepatitis.</li>
<li>12. Skin Conditions: Such as acne, eczema, psoriasis, and skin cancer.</li>
<li>13. Sleep Disorders: Including insomnia, sleep apnea, and narcolepsy.</li>
<li>14. Reproductive Health Issues: Such as infertility, erectile dysfunction, and sexually transmitted infections.</li>
<li>15. Allergies: Including hay fever, food allergies, and allergic dermatitis.</li>
<li>16. Autoimmune Diseases: Such as rheumatoid arthritis, lupus, and celiac disease.</li>
<li>17. Vision and Eye Disorders: Including myopia, cataracts, glaucoma, and macular degeneration.</li>
<li>18. Dental and Oral Health Issues: Such as tooth decay, gum disease, and oral cancer.</li>
</ol>





</div>

	<?php include '../components/footer.php'; ?>


  
  





</body>
</html>


