<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "test";

$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Count total resident visits
$sqlTotalVisits = "SELECT COUNT(*) AS total_visits FROM members";
$resultTotalVisits = mysqli_query($conn, $sqlTotalVisits);
$rowTotalVisits = mysqli_fetch_assoc($resultTotalVisits);
$totalVisits = $rowTotalVisits['total_visits'];

// Count total male
$sqlTotalMale = "SELECT COUNT(*) AS total_male FROM members WHERE gender = 'Male'";
$resultTotalMale = mysqli_query($conn, $sqlTotalMale);
$rowTotalMale = mysqli_fetch_assoc($resultTotalMale);
$totalMale = $rowTotalMale['total_male'];

// Count total female
$sqlTotalFemale = "SELECT COUNT(*) AS total_female FROM members WHERE gender = 'Female'";
$resultTotalFemale = mysqli_query($conn, $sqlTotalFemale);
$rowTotalFemale = mysqli_fetch_assoc($resultTotalFemale);
$totalFemale = $rowTotalFemale['total_female'];

// Find the most provided service
$sqlMostService = "SELECT service, COUNT(*) AS service_count FROM members GROUP BY service ORDER BY service_count DESC LIMIT 1";
$resultMostService = mysqli_query($conn, $sqlMostService);
$rowMostService = mysqli_fetch_assoc($resultMostService);
$mostService = $rowMostService['service'];

// Find the month with the most visits
$sqlMostVisitsMonth = "SELECT MONTH(date) AS month, COUNT(*) AS visit_count FROM members GROUP BY month ORDER BY visit_count DESC LIMIT 1";
$resultMostVisitsMonth = mysqli_query($conn, $sqlMostVisitsMonth);
$rowMostVisitsMonth = mysqli_fetch_assoc($resultMostVisitsMonth);
$mostVisitsMonth = date('F', mktime(0, 0, 0, $rowMostVisitsMonth['month'], 1));

// Count total staff members
$sqlTotalStaff = "SELECT COUNT(*) AS total_staff FROM staff";
$resultTotalStaff = mysqli_query($conn, $sqlTotalStaff);
$rowTotalStaff = mysqli_fetch_assoc($resultTotalStaff);
$totalStaff = $rowTotalStaff['total_staff'];


mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/st.css">
    <!-- Include font awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>

    <?php include '../components/header.php'; ?>

    <?php require_once "../components/navbar.php"?>

    <div class="container">
        <div class="card">
            <h2>Total Resident Visits</h2>
            <p>Functionality: Display the total number of resident visits.</p>
            <i class="fas fa-users"></i> <!-- Icon for total resident visits -->
            <span><?php echo $totalVisits; ?></span>
        </div>

        <div class="card">
            <h2>Total Male</h2>
            <p>Functionality: Display the total number of male residents.</p>
            <i class="fas fa-male"></i> <!-- Icon for total male -->
            <span><?php echo $totalMale; ?></span>
        </div>

        <div class="card">
            <h2>Total Female</h2>
            <p>Functionality: Display the total number of female residents.</p>
            <i class="fas fa-female"></i> <!-- Icon for total female -->
            <span><?php echo $totalFemale; ?></span>
        </div>

        <div class="card">
            <h2>Most Service Provided</h2>
            <p>Functionality: Display the most provided service.</p>
            <i class="fas fa-concierge-bell"></i> <!-- Icon for most service provided -->
            <span><?php echo $mostService; ?></span>
        </div>

        <div class="card">
            <h2>Month with the Most Visits</h2>
            <p>Functionality: Display the month with the most visits.</p>
            <i class="fas fa-calendar-alt"></i> <!-- Icon for most visits in a month -->
            <span><?php echo $mostVisitsMonth; ?></span>
        </div>

        <div class="card">
            <h2>Staff Count</h2>
            <p>Functionality: Display the total number of staff members.</p>
            <i class="fas fa-user"></i> <!-- Icon for staff count -->
            <span><?php echo $totalStaff; ?></span>
        </div>
        
    </div>
 
    <?php include '../components/footer.php'; ?>

</body>
</html>
