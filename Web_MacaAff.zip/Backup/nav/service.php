<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>

    <?php include '../components/header.php'; ?>

    <?php require_once "../components/navbar.php"?>

  
    <div class="container">
      <h1>Services</h1>
      <br>
        <div class="item_wrap">
            <div class="item">Primary care services <strong>Checkup</strong> encompass a broad range of healthcare offerings designed to address individuals' basic medical needs. These services often serve as the first point of contact within the healthcare system and may include routine check-ups, management of acute and chronic conditions, preventive care, and health education.</div>
            <div class="item">Pediatrics <strong>Blood pressure Check(BP)</strong>focuses specifically on the healthcare needs of children, from infancy through adolescence. Pediatric services typically include well-child visits, immunizations, developmental screenings, and management of childhood illnesses and conditions.</div>
        </div>
        <div class="item_wrap">
            <div class="item">Women's health services cater to the unique healthcare needs of women across the lifespan. This may include reproductive health services, such as contraception and family planning, prenatal and postnatal care, gynecological exams, breast health services, and menopause management.</div>
            <div class="item">Chronic disease management involves the ongoing care and support for individuals with long-term health conditions such as diabetes, hypertension, asthma, and arthritis. These services aim to optimize patients' health, minimize symptoms, and prevent complications through medication management, lifestyle modifications, and regular monitoring.</div>
        </div>
        <div class="item_wrap">
            <div class="item">Mental health services encompass a variety of interventions aimed at promoting mental well-being and treating mental health disorders. This may include counseling, psychotherapy, medication management, crisis intervention, and support groups for individuals experiencing conditions such as depression, anxiety, bipolar disorder, and schizophrenia.</div>
            <div class="item">Dental care involves the diagnosis, prevention, and treatment of oral health conditions. Dental services may include routine cleanings, fillings, extractions, root canals, crowns, bridges, and dentures, as well as education on proper oral hygiene practices.</div>
        </div>
        <div class="item_wrap">
            <div class="item">Immunizations are essential preventive measures that help protect individuals from infectious diseases. Immunization services provide vaccines for children, adolescents, and adults to safeguard against illnesses such as measles, mumps, rubella, influenza, tetanus, and hepatitis.</div>
            <div class="item">Laboratory services encompass a wide range of diagnostic tests and procedures performed on specimens such as blood, urine, and tissue samples. These tests aid in the diagnosis, monitoring, and treatment of various medical conditions, including infections, cancers, metabolic disorders, and organ dysfunction.</div>
        </div>
        <!-- Add more service descriptions as needed -->
    </div>

    <?php include '../components/footer.php'; ?>

</body>
</html>
