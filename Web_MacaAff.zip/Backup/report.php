<?php
session_start();
if (!isset($_SESSION["user"])) {
   header("Location: login.php");
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "test";

$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Query to get total number of members
$sqlTotalMembers = "SELECT COUNT(*) AS total_members FROM members";
$resultTotalMembers = mysqli_query($conn, $sqlTotalMembers);
$rowTotalMembers = mysqli_fetch_assoc($resultTotalMembers);
$totalMembers = $rowTotalMembers['total_members'];

// Query to get total number of male members
$sqlTotalMaleMembers = "SELECT COUNT(*) AS total_male_members FROM members WHERE gender = 'Male'";
$resultTotalMaleMembers = mysqli_query($conn, $sqlTotalMaleMembers);
$rowTotalMaleMembers = mysqli_fetch_assoc($resultTotalMaleMembers);
$totalMaleMembers = $rowTotalMaleMembers['total_male_members'];

// Query to get total number of female members
$sqlTotalFemaleMembers = "SELECT COUNT(*) AS total_female_members FROM members WHERE gender = 'Female'";
$resultTotalFemaleMembers = mysqli_query($conn, $sqlTotalFemaleMembers);
$rowTotalFemaleMembers = mysqli_fetch_assoc($resultTotalFemaleMembers);
$totalFemaleMembers = $rowTotalFemaleMembers['total_female_members'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Report</title>
    <link rel="stylesheet" href="../css/styl.css">
    <link rel="stylesheet" href="../css/s.css">
</head>
<body>
    <?php include './components/header.php'; ?>
    <?php require_once "./components/navbar.php"?>
    
    <div class="container">
        <!-- Display Member Report -->
        <h2>Member Report</h2>
        <div>
            <p>Total Members: <?php echo $totalMembers; ?></p>
            <p>Total Male Members: <?php echo $totalMaleMembers; ?></p>
            <p>Total Female Members: <?php echo $totalFemaleMembers; ?></p>
        </div>
        <!-- Button to Print Members List -->
        <button class="print-button" onclick="window.print()">Print Members List</button>
    </div>

    <?php include './components/footer.php'; ?>
</body>
</html>
