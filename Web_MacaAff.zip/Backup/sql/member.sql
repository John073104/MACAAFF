CREATE TABLE members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(255) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    age INT NOT NULL,
    purok VARCHAR(100) NOT NULL,
    address VARCHAR(255) NOT NULL,
    timein TIME NOT NULL,
    timeout TIME NOT NULL,
    service VARCHAR(255) NOT NULL
);
