<div class="wrapper">

	<div class="top_navbar">
		<div class="logo">
			<a href="#">Maca AFF</a>
		</div>
		<div class="top_menu">
			<div class="home_link">
				<a href="../index.php">
					<span class="icon"><i class="fas fa-home"></i></span>
					<span>Member</span>
				</a>
			</div>
			<div class="right_info">
				<div class="icon_wrap">
					<div class="icon">
						<i class="fa regular fa-magnifying-glass"></i>
					</div>
				</div>
				<div class="icon_wrap">
					<div class="icon">
						<i class=""></i>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="main_body">
		
		<div class="sidebar_menu">
	        <div class="inner__sidebar_menu">
	        	
	        	<ul>
		          <li>
		            <a href="../nav/dashboard.php">
		              <span class="icon">
		              	<i class="fas fa-border-all"></i></span>
		              <span class="list">Dashboard</span>
		            </a>
		          </li>
		          <li>
		            <a href="../index.php" class="active">
		              <span class="icon"><i class="fas fa-address-book"></i></span>
		              <span class="list">Residents</span>
		            </a>
		          </li>
		          <li>
		            <a href="../nav/chart.php">
		              <span class="icon"><i class="fas fa-chart-pie"></i></span>
		              <span class="list">Charts</span>
		            </a>
		          </li>
		          <li>
		            <a href="../nav/service.php">
		              <span class="icon"><i class="fas fa-address-card"></i></span>
		              <span class="list">Services</span>
		            </a>
		          </li>
		          <li>
		            <a href="../nav/healthi.php">
		              <span class="icon"><i class="fab fa-blogger"></i></span>
		              <span class="list">Health Issues</span>
		            </a>
		          </li>
		          <li>
		            <a href="../nav/abouts.php">
		              <span class="icon"><i class="fas fa-map-marked-alt"></i></span>
		              <span class="list">About</span>
		            </a>

                    <li>
		            <a href="../php-crud/index.php">
		              <span class="icon"><i class="fa regular fa-user"></i></span>
		              <span class="list">Staff</span>
		            </a>
		           </li>
							 

                <li>
		            <a href="../report.php">
		              <span class="icon"><i class="fa regular fa-clipboard"></i></span>
		              <span class="list">Reports</span>
		            </a>
		           </li>

                   <li>
		            <a href="../nav/team.html">
		              <span class="icon"><i class="fa-regular fa-circle"></i></span>
		              <span class="list">Team</span>
		            </a>
		           </li>

                   <li>
		            <a href="logout.php">
		              <span class="icon"><i class=""></i></span>
		              <span class="list"></span>
		            </a>
		           </li>
		    

		          </li>
		          <li>
		            <a href="../logout.php">
		              <span class="icon"><i class="fas fa-long-arrow-alt-left"></i></span>
		              <span class="list">Logout</span>
		            </a>
		          </li>
		        </ul>

		        <div class="hamburger">
			        <div class="inner_hamburger">
			            <span class="arrow">
			                <i class="fas fa-long-arrow-alt-left"></i>
			                <i class="fas fa-long-arrow-alt-right"></i>
			            </span>
			        </div>
			    </div>

	        </div>
	    </div>