<?php
session_start();
if (!isset($_SESSION["user"])) {
   header("Location: login.php");
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "test";

$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch member details based on ID
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM members WHERE id='$id'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
} else {
    echo "Invalid member ID";
    exit;
}

// Update Member
if(isset($_POST['update_member'])) {
    $id = $_POST['id'];
    $fullname = $_POST['fullname'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];
    $purok = $_POST['purok'];
    $address = $_POST['address'];
    $timein = $_POST['timein'];
    $timeout = $_POST['timeout'];
    $date = $_POST['date']; // Added date field
    $service = $_POST['service'];

    $sql = "UPDATE members SET fullname='$fullname', gender='$gender', age='$age', purok='$purok', 
            address='$address', timein='$timein', timeout='$timeout', date='$date', service='$service' WHERE id='$id'";

    if (mysqli_query($conn, $sql)) {
        echo "Member updated successfully";
    } else {
        echo "Error updating member: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Member</title>
</head>
<body>
    <?php include './components/header.php'; ?>
    <?php require_once "./components/navbar.php"?>
    
    <div class="container">
        <!-- Edit Member Form -->
        <h2>Edit Member</h2>
        <form method="POST" action="">
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
            <input type="text" name="fullname" placeholder="Full Name" value="<?php echo $row['fullname']; ?>" required><br>
            <input type="text" name="gender" placeholder="Gender" value="<?php echo $row['gender']; ?>" required><br>
            <input type="number" name="age" placeholder="Age" value="<?php echo $row['age']; ?>" required><br>
            <input type="text" name="purok" placeholder="Purok" value="<?php echo $row['purok']; ?>" required><br>
            <input type="text" name="address" placeholder="Address" value="<?php echo $row['address']; ?>" required><br>
            <label for="timein">Time In:</label>
            <input type="time" name="timein" id="timein" value="<?php echo $row['timein']; ?>" required><br>
            <label for="timeout">Time Out:</label>
            <input type="time" name="timeout" id="timeout" value="<?php echo $row['timeout']; ?>" required><br>
            <label for="date">Date:</label>
            <input type="date" name="date" id="date" value="<?php echo $row['date']; ?>" required><br> <!-- Added date field -->
            <input type="text" name="service" placeholder="Service" value="<?php echo $row['service']; ?>" required><br>
            <button type="submit" name="update_member" class="btn btn-primary">Update Member</button>
        </form>
    </div>
             <li>
		            <a href="../index.php" class="">
		              <span class="icon"><i class="fas fa-long-arrow-alt-left"></i></span>
		              <span class="list">Residents</span>
		            </a>
		          </li>
    <?php include './components/footer.php'; ?>
</body>
</html>
